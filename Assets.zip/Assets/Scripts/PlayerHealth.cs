﻿using UnityEngine;
using TMPro; // Необходим для работы с TextMeshPro

public class PlayerHealth : MonoBehaviour
{
    // --- НАСТРОЙКИ ЗДОРОВЬЯ ---
    [Header("Health Settings")]
    public int maxHearts = 3;
    public int currentHearts;

    [Header("UI Hearts (TextMeshProUGUI)")]
    // Используем TextMeshProUGUI, поскольку ваши сердечки, вероятно, являются текстом
    public TextMeshProUGUI heart1;
    public TextMeshProUGUI heart2;
    public TextMeshProUGUI heart3;

    // --- НАСТРОЙКИ МОНЕТ ---
    [Header("Coin Settings")]
    public TextMeshProUGUI coinCountText; // UI для отображения счета монет ("Монеты: 0 / 10")
    private int coinsCollected = 0;
    private int totalCoins = 10; // Общее количество монет на уровне

    // --- НАСТРОЙКИ ВОЗРОЖДЕНИЯ (RESPAWN) ---
    [Header("Respawn Settings")]
    public float deathYLevel = -3f; // Высота, ниже которой считается "мертвая зона"

    // Приватные переменные для хранения точки возрождения
    private Vector3 respawnPosition;
    private Quaternion respawnRotation;
    private Rigidbody rb;

    // Вызывается при первом запуске
    void Start()
    {
        // Получаем Rigidbody, чтобы можно было сбросить скорость при возрождении
        rb = GetComponent<Rigidbody>();
        if (rb == null)
        {
            Debug.LogWarning("Rigidbody не найден на игроке. Сброс скорости при возрождении не будет работать.");
        }

        // 1. Сохраняем начальную позицию игрока (установленную в Инспекторе) как точку возрождения
        respawnPosition = transform.position;
        respawnRotation = transform.rotation;

        // 2. Инициализация здоровья и UI
        currentHearts = maxHearts;
        UpdateHeartsDisplay();
        UpdateCoinDisplay(); // Устанавливаем начальное значение счета монет
    }

    // Вызывается каждый кадр
    void Update()
    {
        // Проверяем, упал ли игрок в мертвую зону
        if (transform.position.y < deathYLevel)
        {
            TryLoseHeart();
        }
    }

    // --- МЕТОДЫ ЗДОРОВЬЯ И ВОЗРОЖДЕНИЯ ---

    // Защитный метод, чтобы игрок не терял несколько жизней за один кадр при падении
    private void TryLoseHeart()
    {
        if (currentHearts > 0)
        {
            LoseHeart();
            TeleportToRespawn();
        }
    }

    // Основная логика потери жизни
    public void LoseHeart()
    {
        if (currentHearts > 0)
        {
            currentHearts--;
            UpdateHeartsDisplay();
            Debug.Log("Потеряно сердце! Осталось: " + currentHearts);
        }

        if (currentHearts <= 0)
        {
            Die();
        }
    }

    // Логика смерти и конца игры
    private void Die()
    {
        Debug.Log("Game Over! Жизни закончились.");
        // Здесь можно добавить: Time.timeScale = 0; или SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    // Телепортирует игрока и сбрасывает инерцию
    private void TeleportToRespawn()
    {
        // СБРОС СКОРОСТИ ОБЯЗАТЕЛЕН для предотвращения проваливания сквозь пол
        if (rb != null)
        {
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }

        transform.position = respawnPosition;
        transform.rotation = respawnRotation;
    }

    // --- МЕТОДЫ СЧЕТА МОНЕТ ---

    // Метод, вызываемый скриптом Collectible.cs при подборе монеты
    public void CollectCoin()
    {
        coinsCollected++;
        UpdateCoinDisplay();

        if (coinsCollected >= totalCoins)
        {
            Debug.Log("Все монеты собраны! Победа!");
            // Добавить логику перехода на следующий уровень
        }
    }

    // --- МЕТОДЫ ОБНОВЛЕНИЯ UI ---

    // Обновляет отображение сердечек
    void UpdateHeartsDisplay()
    {
        // Мы предполагаем, что вы используете цвет для отображения сердечек (красный/серый)
        if (heart1 != null) heart1.color = currentHearts >= 1 ? Color.red : Color.gray;
        if (heart2 != null) heart2.color = currentHearts >= 2 ? Color.red : Color.gray;
        if (heart3 != null) heart3.color = currentHearts >= 3 ? Color.red : Color.gray;
    }

    // Обновляет отображение счета монет
    void UpdateCoinDisplay()
    {
        if (coinCountText != null)
        {
            coinCountText.text = "Монеты: " + coinsCollected + " / " + totalCoins;
        }
    }
}