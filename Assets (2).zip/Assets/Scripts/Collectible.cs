﻿using UnityEngine;

// Этот скрипт должен быть прикреплен к объекту монеты
public class Collectible : MonoBehaviour
{
    // ✨ НОВАЯ ПЕРЕМЕННАЯ: Ссылка на префаб системы частиц
    // Вы должны назначить префаб эффекта взрыва через Инспектор!
    public GameObject coinExplosionPrefab;

    void OnTriggerEnter(Collider other)
    {
        // 1. Проверяем, что в триггер вошел объект с тегом "Player"
        if (other.CompareTag("Player"))
        {
            // 2. Находим компонент PlayerHealth на этом объекте.
            PlayerHealth playerHealth = other.GetComponent<PlayerHealth>();

            if (playerHealth != null)
            {
                // 3. Сообщаем PlayerHealth о сборе монеты
                playerHealth.CollectCoin();

                // 🌟 ДОБАВЛЕННЫЙ КОД: Запускаем эффект взрыва
                PlayExplosionEffect();

                // 4. Уничтожаем текущий объект монеты
                Destroy(gameObject);
            }
            else
            {
                Debug.LogError("Collectible: Объект игрока не имеет компонента PlayerHealth!");
            }
        }
    }

    // ✨ НОВЫЙ МЕТОД: Для создания и уничтожения эффекта частиц
    void PlayExplosionEffect()
    {
        if (coinExplosionPrefab != null)
        {
            // Создаем (инстанциируем) префаб взрыва
            GameObject explosion = Instantiate(coinExplosionPrefab, transform.position, Quaternion.identity);

            // Опционально: автоматически уничтожаем эффект, когда он закончит проигрываться.
            // Получаем длительность Particle System и уничтожаем объект после этого времени.
            ParticleSystem ps = explosion.GetComponent<ParticleSystem>();
            if (ps != null)
            {
                Destroy(explosion, ps.main.duration);
            }
            else
            {
                // Если ParticleSystem не найден (что нежелательно), уничтожаем через 2 секунды.
                Destroy(explosion, 2f);
            }
        }
    }
}